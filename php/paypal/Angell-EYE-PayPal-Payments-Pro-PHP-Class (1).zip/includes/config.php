<?php
$host_split = explode('.',$_SERVER['HTTP_HOST']);
$sandbox = $host_split[0] == 'sandbox' || $host_split[0] == 'localhost' ? true : false;
$domain = $sandbox ? 'http://sandbox.angelleye.com/' : 'http://www.angelleye.com/';

$api_version = '74.0';
$application_id = $sandbox ? 'APP-80W284485P519543T' : '';
$developer_account_email = 'andrew@angelleye.com';
$api_username = $sandbox ? 'sandbo_1215254764_biz_api1.angelleye.com' : '';
$api_password = $sandbox ? '1215254774' : '';
$api_signature = $sandbox ? 'AiKZhEEPLJjSIccz.2M.tbyW5YFwAb6E3l6my.pY9br1z2qxKx96W18v' : '';
?>